Files scheduled to be removed from Linux documentation tree
===========================================================

The content of the following files have been imported into the spec from the Linux kernel documentation directory and the original source should be removed after the next release of the devicetree specification::

   Documentation/
      devicetree/
         bindings/
            reserved-memory/
               reserved-memory.txt     # Added commit 841c0878

.. SPDX-License-Identifier: Apache-2.0
